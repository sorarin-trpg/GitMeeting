

How to install:
1. Go to link
2. Click "DOWNLOAD"
3. Extract
4. Run the .exe
5. Well done!