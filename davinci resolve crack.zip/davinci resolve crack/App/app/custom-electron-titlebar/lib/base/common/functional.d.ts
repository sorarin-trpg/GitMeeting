export declare function once<T extends Function>(this: unknown, fn: T): T;
